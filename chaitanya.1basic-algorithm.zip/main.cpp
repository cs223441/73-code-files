

/*1. Write a C++ program to get the absolute difference between n and 51. 
        
     If n is greater than 51 return triple the absolute difference.*/
  
  
  
#include<iostream>

using namespace std;

int main(){
    
    int n,o,g,h;
   
    o=51;
    
    cout<<"enter value of n:";
    cin>>n;
    
    if(n>o){
        
        g=(o-n)*3;
        
        cout<<"diffrence:"<<g;
        
    }
  
  else{
      
      g=o-n;
      cout<<"diffrence:"<<g;
  }
 
  
  
  return 0;
 
  
  
    
    
    
}