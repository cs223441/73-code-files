

# Q x to y value transferring and making x empty

x=int(input("enter integer values of x list::"))

x=list[x]
y=[]

h=0
while h<=x(len):
        
        r=x.pop(x[h])
        y=r.append(y)
        
        x=x.remove()
        
        h=h+1
        
        print(y)
        
else:
    print("completed!")