
#for loop:

'''

**for loop is the iteration of iterable elements 

**iterable elements :: the elements those are arranged in a perticular sequence and can be looped again and again

**iterable objects :: list, string, tuple, dictionary etc 

'''

f="chaitanya"
for i in f :
    print(i)

g="hello world"

for d in g:
    if d==" ":
        continue
    print(d)
    break

    
l=[1,2,3,4,5,7,8]
for v in l:
    if(v==4):
        continue
    print(v)
else: 
    print("done!")


y={"name":"chaitanya","email":"chaitanya43455@gmail.com","gender":"male"}

for t in y:
    print(y.keys())
    
for g in y:
    print(y.values())

    
    
t=[1,2,3,4,5,6,7,8]
for k in t :
    if(k%2==0):
        print("even no:",k)
    else:
        print("odd no:",k)
        

d=[1,2,3,4,5,6,7,8]
even=[]
odd=[]

for r in d :
    f=d.pop(r)
    
    if(k%2==0):
        even.append(f)
        print("even no:",even)
    else:

        odd.append(f)
        print("odd no:",odd)
        
    