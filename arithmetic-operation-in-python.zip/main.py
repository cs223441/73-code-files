'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
l= input("enter length:")

a= int(l)

b =input("input width:")

c= int(b)

area=a*c

print (area)