/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class student{ //class:
    public:
    int roll;//data member
    char name[23];//data member
    char lname[15];//data member
    char section[1];//data member

    void input() { // member function 
    
        cout<<"enter roll:";
        cin>>roll;
        
        cout<<"enter fname:";
        cin>>name;
        
        cout<<"enter lname:";
        cin>>lname;
        
        cout<<"enter section:";
        cin>>section;
    };
    void output(){ // member function
      cout<<"roll:"<<roll<<endl;
      cout<<"fname:"<<name<<endl;
      cout<<"lname:"<<lname<<endl;
      cout<<"section:"<<section;
    };
};
int main() // main function
{
    student newobj;//object
    newobj.input();
    newobj.output();
    
    return 0;
}
