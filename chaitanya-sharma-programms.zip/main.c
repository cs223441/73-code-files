/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int i,c,d;
for(i=0;i<=6;i++ ){
    for(c=6;c>=i;c--){
        printf("%di");
printf("\n");        
    }
    for(d=1;d<=6;d++){
        printf("%d*");
    }
}
    return 0;
 }
