/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;


int main()
{
float cone_vol;
int r;
int h;

cout<<"enter r,h";
cin>>r>>h;

cone_vol:1/3*(3.14*r*r*h);

cout<<"cone_vol:"<<cone_vol;
return 0;
}
