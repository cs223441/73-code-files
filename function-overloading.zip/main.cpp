/******************************************************************************

function overloading : using a same named function with different argument to get different outputs in same programm is called function overloading

*******************************************************************************/

//eg:
#include<iostream>
#include <stdio.h>
using namespace std;
class j{
    public:
    
    void add(int a,int b){
        cout<<a+b<<endl;
    }
    void add(float yu,int ii,int hj){
        cout<<yu+ii+hj<<endl;
    }
    void add(float t, int y, double io){
        cout<<t+y+io<<endl;
    }
};


int main()
{
    j st;
    st.add(10,20);
    st.add(2.2,3,4.56);
    st.add(6.2,4,9);
    return 0;
}
