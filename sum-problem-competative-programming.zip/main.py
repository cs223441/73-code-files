j=int(input("enter no1 : "))
k=int(input("enter no2 : "))
l=int(input("enter no3 : "))
def s(j,k,l):
    sm=j+k+l
    print(f"sum of {j},{k},{l} : {sm}")
s(j,k,l)