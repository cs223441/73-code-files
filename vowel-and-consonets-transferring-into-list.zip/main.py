
''' 
[a e i o u- vowels]

Q make three lists saperate vowel into vowel named list and others in consonants

'''



y=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p"]
vowel=[]
consonents=[]

j=0
while j<=y.(len):
    g=y.pop(y[j])
    
    if(g=="a" or g=="e" or g=="i" or g=="o" or g=="u"):
    
        vowel=vowel.append(g)
    else:
        consonents=consonents.append(g)
        
    j=j+1
    
    print(vowel)
    print(consonetns)
        
else:
     y.remove()
     print(y)