/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

class xy{

public:
int a,b;

void putdata();
void getdata();
};

void xy::putdata(){
    cout<<"enter name age : ";
    cin>>a;
    cout<<"enter roll : ";
    cin>>b;
    cout<<endl;
    cout<<endl;
}

void xy::getdata(){

    cout<<"age:"<<a<<endl;
    cout<<"roll:"<<b<<endl;
    cout<<endl;
}

int main()
{
    xy h[1];//this is the limit of stack , program cannot insert values more than the [value]!
    
    int i,n;
    cout<<"how many times:";
    cin>>n;
    
    for (i=0;i<n;i++){
        h[i].putdata();
        }
        cout<<"-------output---------";
        cout<<endl;
    for (i=0;i<n;i++){
        h[i].getdata();
        }
return 0;

}


