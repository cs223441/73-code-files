g=[1,2,3,4,5,6,7,8,9,10]
h=[]
j=[]

i=0
while i<len(g):
    c=g.pop(i)
    if(c%2==0):
        h.append(c)
        print("your h values is :",h)
    else:
        j.append(c)
        print("your j values is :",j)
else:
    print("done!")
  
