f=[3.43,654,52,42]
import math

result=math.fsum(f)
print(result)



t=[33,13,56,13,5]
import math

result2=math.fsum(t)
print(result2)