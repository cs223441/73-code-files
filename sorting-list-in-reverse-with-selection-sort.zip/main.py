'''
sorting list in reverse with help of selection sort
'''

t=[1,2,3,4,5,6,7,8,9,10]

for i in range(0,len(t)-1):
    for y in range(i+1,len(t)):
        if(t[i]<t[y]):
            sp=t[i]
            t[i]=t[y]
            t[y]=sp
print(t)