'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
'''
for i in range(7):
    d=1
    for d in range(1,i+1,1):
        print("*",end="")
    else:
        print(" ")
   '''   


# pattern 1
'''
for u in range(8):
    t=-1
    for t in range(t,u,1):
        print(" * ",end="")
    else:https:
        print(" ")
        
        
for i in range(8):
    d=7
    for f in range(d,i-1,-1):
         print(" * ",end="")
    else:
        print("")
       
 
#pattern 2
'''
'''
for i in range(0,5,1):
    
    for o in range(4,-1,-1):
        print("  ")
        
        for f in range(0,i,1):
            print("*",end="")
else:
    print(" ")
    
'''

    

