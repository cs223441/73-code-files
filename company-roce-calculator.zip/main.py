
#ROCE = earning before interest and tax / capital employed

name=str(input("enter name of company:"))

ebit=float(input("Enter EBIT Units:"))
ce=float(input("Enter Capital Employed:"))

ROCE=ebit/ce
print(name,"company ROCE is:",ROCE,"units")