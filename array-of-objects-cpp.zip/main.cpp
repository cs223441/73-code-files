/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class student
{
public:
  int id;
  char name[15];

  void set ();
  void get ();
};

void
student::set ()
{
  cout << "enter id: ";
  cin >> id;
  cout << "enter name: ";
  cin >> name;
}

void
student::get ()
{

  cout << "id : " << id << endl;
  cout << "name : " << name << endl;
}

int main ()
{
  student st[20];
  int f, a;

  cout << "enter no of students : ";
  cin >> a;

  for (f = 0; f < a; f++)
    {
      st[f].set ();
    }

  cout << "-------OUTPUT---------" << endl;
  for (f = 0; f < a; f++)
    {
      st[f].get ();
    }

  return 0;
}

