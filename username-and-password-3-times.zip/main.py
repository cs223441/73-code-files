'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
c=input("enter username:")
b=input("enter password:")
if(c=="chaitanya" and b=="123"):
    print("2 more times-")
    if(c!="chaitanya" and b!="123"):
        print("please enter valid details and try again")
        print(c)
        print(b)

    c=input("enter username:")
    b=input("enter password:")
    if(c=="mohit" and b=="123"):
        print("one more time-")
        if(c!="mohit" and b!="123"):
            print("please enter valid details and try again")
            print(c)
            print(b)

    c=input("enter username:")
    b=input("enter password:")
    if(c=="arpit" and password=="123"):
        print("that's right, now enter your pincode to know your location:")

        if(c!="arpit" and password!="123"):
            print("please enter valid details and try again:")