
import random

#min = -1
#max=10
#
#r=random.randint(min,max)
#print(r)

d=5
g=10

h=random.randint(d,g)
print(h)