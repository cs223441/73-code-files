#include <iostream>

using namespace std;

class employee{
    public:
    
    int id , age;
    float salary;
    char fname[20];
    char lname[20];
    
    void input();
    void output();
    
};
void employee :: input(){
    cout<<"Enter id : ";
    cin>>id;
    cout<<"\n";
    
    cout<<"Enter age : ";
    cin>>age;
    cout<<"\n";
    
    cout<<"Enter salary : ";
    cin>>salary;
    cout<<"\n";
    
    cout<<"Enter fname : ";
    cin>>fname;
    cout<<"\n";
    
    cout<<"Enter lname : ";
    cin>>lname;
    cout<<"\n";
    
}

void employee :: output(){
    cout<<"id : "<<id<<endl;
    cout<<"age : "<<age<<endl;
    cout<<"salary : "<<salary<<endl;
    cout<<"fname : "<<fname<<endl;
    cout<<"lname : "<<lname<<endl;
}

int main()
{
int g,h;
employee emp;

cout<<"enter no of employee : ";
cin>>h;
cout<<"\n";
for (g=0;g<h;g++){
    emp.input();
    cout<<"\n";
}

cout<<"\n---DETAILS---"<<endl;
cout<<"\n";

for (g=0;g<h;g++){
    emp.output();
    cout<<" \n ";    
}
  return 0;
}
