#Current Market Price per share * Total Number of Outstanding Shares.

name=str(input("Enter Company Name.."))
cmps=float(input("Enter Current Market Price Per Share.."))
tos=float(input("Enter Total Number Of Outstanding Shares.."))

mc=cmps*tos

print(name,"Has",mc,"Market Capitalization")