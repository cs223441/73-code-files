'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
t=int(input("search for number:"))
l=[1,2,3,4,5,6,7,8]
for i in range(len(l)):
    if l[i]==t:
        print(f"your number {t} is at {i}")
        