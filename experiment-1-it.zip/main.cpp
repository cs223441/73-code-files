/******************************************************************************

1. Write a C++ Program to display Names, Roll No., and grades of 3 students who have 
appeared in the examination. Declare the class of name, Roll No. and grade. Create an array 
of class objects. Read and display the contents of the array

*******************************************************************************/
#include <iostream>
using namespace std;

class students{
    public:
    
    char name[20];
    int roll;
    int total;
    int marks;
    float percent;

    void getdata();
    void setdata();

};

void students::getdata(){
    cout<<"enter students details : "<<endl;
    cout<<endl;
    cout<<"enter name : ";
    cin>>name;
    
    cout<<"enter roll : ";
    cin>>roll;
    
    cout<<"enter total :";
    cin>>total;
    
    cout<<"enter obtained marks: ";
    cin>>marks;
}

void students::setdata(){
    percent=(marks/total)*100;
    cout<<"name : "<<name<<endl;
    cout<<"roll : "<<roll<<endl;
    cout<<"total : "<<total<<endl;
    cout<<"obtained marks out of "<<total<<" : "<<marks<<endl;
    cout<<"percentage obtained : "<<percent<<"%";
    cout<<endl;
    cout<<endl;
}

int main()
{
    students s1[20];
    
    int a,b;
    cout<<"no. of students : ";
    cin>>b;
    cout<<endl;
    
    for (a=0;a<b;a++){
        s1[20].getdata();
    
        cout<<endl;
    }
    
    for (a=0;a<b;a++){
        cout<<"student "<<a+1<<" details:"<<endl;
        cout<<"---------------------------";
        cout<<endl;
        s1[20].setdata();
    }
   
    return 0;
}


