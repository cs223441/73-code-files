

#Selection sort:selects the backward element and compares and swaps
#Example:-

print()
print()
print()
print()
i=[3,4,41,1,3,4,52,4,13,4,52,1,3,5,6,23,5,52,4,6,7,857546,758,9,57,4,35,3,53,7464323,5,68785,995,64,23,23,5674,85,8]
for u in range(1,len(i)):
    k=u
    while i[k]<i[k-1] and k>0:
                    sw=i[k]
                    i[k]=i[k-1]
                    i[k-1]=sw
                                            
                    k=k-1
print(f"sorted list:{i}")
print()
print()
print()
print()

#insertion sort:two consequent loops run together with comparing there values together
#Example:-
            
g=[32,3,6234,667,23,12,3256,7,234661,123,5,612,563,612,624,67,12,4,1,2,3,6,123,6,714,6]

for first in range(0,len(g)):
    for second in range(first+1,len(g)):
        if(g[first]>g[second]):
        
            swap=g[first]
            g[first]=g[second]
            g[second]=swap
print(f"sorted list:{g}")
print()
print()
print()

#Bubble sort:two loops are running together if l[i]>l[i+1]:swap just like Bubble
#Example

h=[10,9,8,7,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-7,-8,-9,-10]

for j in range(0,len(h)-1):
    for y in range(0,len(h)-1):
        
        if(h[y]>h[y+1]):
            
            hg=h[y]
            h[y]=h[y+1]
            h[y+1]=hg
print(f"sorted list:{h}")