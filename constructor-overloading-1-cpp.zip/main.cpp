/*

constructor overloading : .defining the constructor multiple times with same name withing the class having different data types or
-----------------------    sizes is called constructor overloading
                          .all constructors will have same name as class name
*/

//eg: program having multiple constructors with different argument types and quantity
#include <iostream>
using namespace std;

class jk{
    public:
    float area;
    
    jk(){
         area = 44;
        
    }
    jk(float pie, float r){
        area = pie*r*r;
        
    }
    jk( int a ){
        area=a*a;
    }
    void display(){
        cout<<area<<endl;    
    }
};

int main(){
    jk lo;
    jk lo2(3.14,3);
    jk lo3(4);
    
    
    lo.display();
    lo2.display();
    lo3.display();
}