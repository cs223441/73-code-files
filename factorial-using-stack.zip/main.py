#factorial:
#correct:

p=[5,4,3,2,1,0]
top=0
fact=1
for i in range(top,len(p)-1):
    fact=fact*p[top]
    top+=1
print(fact)