/*

3. Write a C++ program to check two given integers, and return true if one of them is 30 or if their sum is 30.

                                                                                                               */
#include <iostream>
using namespace std;
int main()
{
    int a,b,g;
    
    cout<<"enter a:";
    
    cin>>a;
    
    cout<<"enter b:";
    
    cin>>b;
    
    g=a+b;
    
    if(a==30){
        
        cout<<"true";
    }
    else if (b==30){
       
         cout<<"true";
        
    }
    else if(g==30){
     
        cout<<"true";
    
        
    }
    
    else{
        
        cout<<"false";
    }
    
    return 0;
}
