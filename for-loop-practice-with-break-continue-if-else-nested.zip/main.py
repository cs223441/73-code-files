
#for loop::

p="python"
for i in p: 
    print(i)
    
k="hello world"
for j in k:
    print(k)
    
g="i like coding"
for u in g:
    print(u)
    
l="diablo 2"
for i in l:
    print(i)
    
g="chaitanya"
for o in g:
    if o=="t":
        break
    print(o)
    
k="govind"
for i in k:
    if(i=="i"):
        break
    print(i)
    
    
g="krishna sharma"
for i in g :
    if(i=="a"):
        break
    print(i)
    
f="i love coding"
for k in f:
    if(i=="c"):
        break
    print(k)
    
h="vjsign"
for k in h:
     if(k=="s"):
         break
     print(k)
     
h=[1,2,3,4,5,6]
for j in h:
    if(j==4):
        continue
    print(j)
    
g=(1,2,3,4,5,5)
for k in g :
    if(k==2):
        continue
    print(k)
    
s="chaitanya"
for j in s:
    if(j=="t"):
        continue
    print(j)
    
f="sharma"
for k in f:
    if(k=="r"):
        continue
    print(k)
    
a="chaitanya"
for d in a:
    if(d=="a"):
        continue
    print(d)
    
s="chaitanya"
for j in s:
    if(j=="t"):
        continue
    print(j)
    
    
k="chaitanya"
for i in k:
    if(i=="a"):
        print("index value has got a")
        continue
    else:
        print("not found")
        
l=[1,2,3,4,5,6,7]
for k in l:
    if(k==4):
        print("got no",4)
        break
    else:
        print("not found")
        
p=[2,3,4,5,6,7,8]
for o in p :
    if(o==5):
        continue
        print("found number",o)
        
    else:
        print("no")
        
f="chaitanya"
for i in f:
    if(i=="a"):
        print("found",i)
    else:
        print("not found")
        
y="i love coding"
for i in y:
    if(i=="c"):
        print("found",i)
    else:
        print("not found",i)
        
l="chaitanya sharma"
for p in l:
    if(p=="s"):
        print("found s and breaking the loop")
        break
    else:
        print("not found s but found",p)
        

#for loop in range:

i=0
for i in range(10):
    print("no:",i)


g="chaitanya"
for i in range(len(g)):
    print(g[i])

u="HELLO WORLD"
for i in range(len(u)):
    print(u[i])
    
r=[1,2,3,4,5,6]
for i in range(1,len(r),2):
    print(r[i])
    

for e in range(1,5,2):
    print(e)

for i in range(0,10,3):
    print(i)

for o in range(10,1,-2):
    print(o)
    
for j in range(100,0,-10):
    print(j)
    
for p in range(200,0,-100):
    print(p)

for i in range(10,0,-3):
    print(i)
    
for o in range(50,5,-5):
    print(o)
    '''
f= input("enter your name:")
for g  in range(1,len(f),2):
    print(f[g],end="" )
    '''
g="hello world"
for j in range(0,len(g),1):
    print(g[j], end="" )

f="hello chaitanya sharma how are you??"
for i in range(0,len(f),1):
    print(f[i], end="" )
    

for g in range(-11,11,1):
    print(g)
    
for i in range(-50,10,2):
    print(i)
    

for i in range(20,-21,-1):
    print(i)
    print()
    
h="chaitanya"
for i in range(8,-1,-1):
    print(h[i],end="")
    
   
print()
for i in h:
    print(i,end="")
    print()
''' 
i=input("enter you name:")
o=int(input("how many characters you want to delete:"))

for g in range(0,len(i)-o,1):
    print(i[g],end="")

print()

name="chaitanya"
for c in range(1,len(name),1):
    for c in range(0,len(name),1):
        print(c+name[c] )
'''
for i in range(0,3,1):
    x=int(input("enter x:"))
    y=int(input("enter y:"))
    z=int(input("enter z:"))

    
    if(x>y and x<z):
        print("y is smallest,x is second greatest and z is greatest")
        if(x>z and x<y):
            print("z is smallest, x is second greatest and y is greatest")
    elif(y>x and y<z):
        print("x is smallest, y is second greatest and z is greatest")
        if(y>z and y<x):
            print("z is smallest, y is second greatest and x is greatest")
    
    
    elif(z>y and z<x):
        print("y is smallest, z is second greatest and x is greatest")
        if(z>x and z<y):
            print("x is smallest, z is second greatest and y is greatest")
    
else:
    
    print("done!")
    


    
    