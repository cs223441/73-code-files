/*
defining member function inside and 
outside class : this is normal function , this type of functions only be accesed or used only from inside the class
*/

#include <iostream>

using namespace std;

//inside the class
/*
class A{
    public:
    char name[20];
    void set(){
        cout<<"What is your name : ";
        cin>>name; 
    }
    
    void get(){
        cout<<"nice "<<name<<"!";
    }
};

int main()
{
   A fir;
   fir.set();
   fir.get();
}

*/
// outside the class: we have to use socope resolution operator (::) to tell class that the function is part of class and defined outside the class
// this type of function is called global function , it can be used by multiple classes

//using gloval variable using scope resolution operator

/*
int y=20;

class jo{
public:
void out(){
    int z = 30;
    cout<<"z : "<<z;
    cout<<" y : "<<::y;
 }
 
};

int main(){
    jo newob;
    newob.out();
};
*/

//declaring member function outside the class and accessing it using sope resolution operator

class student{
    public:
    int age;
    int roll;
    char fname[20];
    char lname[20];
    
    void set(){
        cout<<"enter age : ";
        cin>>age;
        cout<<"enter roll : ";
        cin>>roll;
        cout<<"enter fname : ";
        cin>>fname;
        cout<<"enter lname : ";
        cin>>lname;
        
    }
    
    void get();
};

void student :: get(){
    cout<<"-----------details-------------"<<endl;
    cout<<"age : "<<age<<endl;
    cout<<"roll: "<<roll<<endl;
    cout<<"fname: "<<fname<<endl;
    cout<<"lname: "<<lname<<endl;
    
};

int main(){
    student ol;
    ol.set();
    ol.get();
return 0;
}