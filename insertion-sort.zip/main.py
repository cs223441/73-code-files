
#selection sort:
'''
p=[3,4,2,2,4,6,7,3,5,7,43,6,8]
for i in range(1,len(p)):
    while i>0 and p[i]<p[i-1]:
        swap=p[i]
        p[i]=p[i-1]
        p[i-1]=swap
        i=i-1
print(p)
            
                    
y=[325,6635,23,52,4,57,84,8,3,2314,6,3,7,356,7,6]
for i in range(1,len(y)):
    while i>0 and y[i]<y[i-1]:
        swap=y[i]
        y[i]=y[i-1]
        y[i-1]=swap
        
        i=i-1
print(y)


t=[4,24,2,5,24,52,6,2,425,66,24,2,52,4525,2,5,2,626,2,5,45]
for v in range(1,len(t)):
    y=v
    while y>0 and t[y]<t[y-1]:
        swap=t[y]
        t[y]=t[y-1]
        t[y-1]=swap
        y=y-1
print(t)
'''
'''
g=[4,13,4,5,13,45,2,3,5,142,4,513,12,415,124,52,135,514,51,521,556,231,521,56,67,21,4,677,95]
for i in range(1,len(g)):
    r=i   
    while r>0 and g[r]<g[r-1]:
        swapping=g[r]
        g[r]=g[r-1]
        g[r-1]=swapping
        r=r-1
print(g)

l=[3,5,52,6,24,6,2,4,6,73,7,3,6,4,25,2,6,7,4,63,6,5,2,52,24,1,31,24,4,235,3,64,6,457,5,658,8,7,46363]
for i in range(1,len(l)):
    t=i
    while t>0 and l[t]<l[t-1]:
        swap=l[t]
        l[t]=l[t-1]
        l[t-1]=swap
        t=t-1
print(l)
'''