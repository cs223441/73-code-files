'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.



def Outer(fname):
    def inner(lname):
        
        print(f"this is full name:{fname+lname}")
      
    inner("sharma")
    
Outer("chaitanya ")



def fname(fname):
    def lname(lname):
        print(f"name : {fname+lname}")
        
    lname("sharmaji")
fname("chaitanya ")



def name(name):
    def course(course):
        print(f"name is :{name} and course is : {course}")
        
    course("computer science engineering")

name("Chaitanya")



def study(course):
    def passion(passion):
        
        print(f"Iam doing study of : {course} but my passion is : {passion}")
    
    passion("singing")

study("computer science")


#P/E=Share price/Earnings per share

print("display the pe ratio of tata:")

def sp(sp):
    
     def eps(eps):
        
            def pe(pe):
                
                pe=sp/eps
                
                print(f"pe ratio of tata is :{pe}")
            
            pe(pe)
     eps(20)
sp(10)
'''

o={1,2,3,4,5,6,7}
u=23
o.pop()
print(o)
