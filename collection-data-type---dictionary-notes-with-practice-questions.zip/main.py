
#----------------------------------DICTIONARY-----------------------------------------------*

#dictionary basic syntax and fetching data using indexing:
#d={} ------> -------> symbol
#keys must be unique
#value can be same 
#data in dictionary is fetched by using it's key name 
#data in list stored in dictionary can be fetched using indexing
#key must be in int or string 
#values can be of any data type
#fetching values from dictionary ----------------> p["name"]["age"]
#fetching values from list stored in dictionary --------------> p["id"][2] ---> using index no. 

'''
pr={"name":{"fname":"chaitanya","lname":"sharma","friends":{"besty":["surendra","ujjwal","sarvesh"],"nasty":["devesh","yogesh","himanshu","deepak"]},"email":{"id":"chaitanya43455@gmail.com","owner":"chaitanya sharma"}}}

print(len(pr[name]))

print(pr["name"]["email"]["id"])

print(pr["name"]["fname"],pr["name"]["lname"],pr["name"]["email"]["id"],pr["name"]["email"]["owner"])

print(pr["name"]["friends"]["besty"][2],pr["name"]["friends"]["nasty"][2])

'''

   #dictionary methods:
'''--------------------'''
#x.update(y):appends a new key and values in existing dictionary
#type(x):returns the type of variable this method can be used in dictionary
#len(x):this function returns the values keys of dictionary
#x.popitem(""):it removes item from ending side of dictionary
#x.pop(key or  value):removes the specific key or value from dictionary
#x.values():returns the all values stored in dictionary
#x.keys():returns all the key names stored in the dictionary
#x.get("key name"):returns the value of specific key
#z=x.copy():copies all the values of dictionary and stores in the left side variable of assignment operator
#x.clear():distroyes all the values from dictionary

#--------------------------practice-----------------------------------#

'''
update function
----------------

x={"name":"chaitanya","lname":"sharma"}

y={"email":"chaitanya43455@gmail.com","freinds":["surendra","sarvesh","devesh","neeraj","nikhil"]}

x.update(y)
print(x)
print(type(x))

type function
-------------

print(type(x))

len function
------------
print(len(x))


pop function
------------
x.pop("email")
print(x)

popitem function
----------------
x.popitem()
print(x)


#values function
y={"email":"chaitanya43455@gmail.com","freinds":["surendra","sarvesh","devesh","neeraj","nikhil"]}
print(y.values())

#y.keys function
y={"email":"chaitanya43455@gmail.com","freinds":["surendra","sarvesh","devesh","neeraj","nikhil"]}
print(y.keys())

#get function 
print(y.get("email"))
print(y.get("freinds"))
print(y.get("freinds")[2])
print(y.get("freinds")[0],y.get("freinds")[3])

#z=x.copy()
y={"email":"chaitanya43455@gmail.com","freinds":["surendra","sarvesh","devesh","neeraj","nikhil"]}

z=y.copy()
print(z)

#y.clear()
y={"email":"chaitanya43455@gmail.com","freinds":["surendra","sarvesh","devesh","neeraj","nikhil"]}
y.clear()
print(y)


#Q1::>>print left side keys and their values in right side of keys 

y={"email":"chaitanya43455@gmail.com","freinds":["surendra","sarvesh","devesh","neeraj","nikhil"]}

u=1
while u<=len(y):
    k=1
    while k<=len(y):
        print(y.values())
        k=k+1
    print(y.keys())
    u=u+1
    
    
#Q2::>>x={"records":{"stud_records":["name","age","course",{"stud_name":["eric","elliot"],"course":["python","Linux"]}]}} ----> print lx of linux

x={"records":{"stud_records":["name","age","course",{"stud_name":["eric","elliot"],"course":["python","Linux"]}]}}

#Ans --> print(x["records"]["stud_records"][3]["course"][1][0::4])

#Q3::>>z={"1":"one","two":2,3:[{"result":[{"name":[{"first_name":"eric","last_name":"stov"},{"age":(11,14,14,{"names":"jack"})}]}]}]} -----> print jk of jack

z={"1":"one","two":2,3:[{"result":[{"name":[{"first_name":"eric","last_name":"stov"},{"age":(11,14,14,{"names":"jack"})}]}]}]}
                        
#Ans --> print(z[3][0]["result"][0]["name"][1]["age"][3]["names"][0::3])

'''

# DICTIONARY SET ----->

# it always stores unique values
#it does not support indexing and slicing
#symobol:{}
#duplicate values are not allowed


# Practice ---->

c={2,3,4,5,6}
print(type(c))

i={3,4,5,7,8}
print(type(i))

u={3,4,6,7,8,4.3,4.5}
print(type(u))

'''
functions of set ---->

x.union(y):combines two sets together(x|y)

x.intersection(y):it returns two or more common sets from the sets(x&y)

x.difference(y):returns the different values from two sets(x-y)

x.symmetric_difference(x^y)

'''

print(c.union(i))
print(c|i)

print(c.intersection(i))
print(c&i)

print(i.difference(c))
print(i-c)

print(c.symmetric_difference(i))
print(c^i)



#Practice questions------------------->

#creating a  2 list that may be contain common element , write to program to fetch common elements.

#Ans1: 
i={1,2,4,5,6}
o={1,2,4,5,6}

print(i.intersection(o))



#creating a  2 list that may be contain un-common element , write to program to fetch un-common elements.

#Ans2:
r={2,4,52,4}
t={3,1,5,7,4}

print(t.difference(r))



#creating a  2 list that may be contain combining element , write to program to fetch combining elements.

#Ans3:
g={1,3,4,5,6,7}
g2={2,3,6,5,56,7}

print(g.union(g2))



p={3,6,7,2,2,5}

q={31,2,4,5,6,74}

print(p.difference(q))

print(p.symmetric_difference(q))

print(p.union(q))

print(p.intersection(q))



f={3,4,6,7,5,7}
o={23,4,5,7,89}
print(f.intersection(o))
print(o.symmetric_difference(f))
print(o.union(f))
print(o.difference(f))


g={"name":"chaitanya","sname":"sharma","email":"chaitanya43455@gmail.com","course":"python"}


r=list(g.keys())
t=list(g.values())

k=0
while k<len(g):
    print(r[k],t[k])
    
    k=k+1
    
    
    

l={"name":"chaitanya","sname":"sharma","roll":"233","course":"python","college":"rck"}

key=list(l.keys())
value=list(l.values())
j=0
while j<=len(l):
    print(key[j],value[j])
    j=j+1