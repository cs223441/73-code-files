

#average stock expense

o=1
while o<2:
    p=int(input("enter early stock price:"))
    
    l=int(input("enter number of stocks you've buyed:"))
    
    r=p*l
    print("your first expense:",r)
    o=o+1



h=1
while h<2:
    i=int(input("enter later stock price: "))
    
    c=int(input("enter number of stocks you've buyed:"))
    
    b=i*c
    print("your second expense:",b)
    h=h+1
    
    
    avg=(r+b)/2

    print("your average expense:",avg)
    

    
