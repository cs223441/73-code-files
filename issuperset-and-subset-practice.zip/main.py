'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
h={3,4,5,2}
k={23,4,52,3,5,2}
print(h.issubset(k))

g={34,24,32}
d={34,24,32}

f={4,5,2,4,5}
d={1,4,4,5,6}
print(f.issubset(d))

a={3,5,3,6,8}
d={3,56,2,5,7}
print(a.issubset(d))

v={4,52,2,5,6}
a={4,32,4,2,52,6,5}
print(a.issubset(v))

a={3,5,6,73}
s={1,2,4,5,6}
print(s.issubset(a))

print(a.issuperset(s))

print(f.issuperset(d))

print(v.issuperset(a))

print(g.issuperset(d))

print(v.issuperset(a))

d={3,4,5}
f={2,3,4,5}
print(f.issuperset(d))

c={3,4,5,32}
s={3,6,7,5,32,4}
print(s.issuperset(c))

print(c.issuperset(s)) 

