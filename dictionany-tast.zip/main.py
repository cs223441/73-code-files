

# dictionary datatype { key:value:pair} -- This data type helps to store and work on key value and pair 

# keys are unique and can of string and integer type, value can be common, 

#fetching values :: x["age/name" or any other keys]

#x={"students":{"names":["saurabh","sachin"]}}

#x.update(y)

#x.pop("name")

#x.keys():gets all the keys of dictionanry

#x.values():gets all the values of the keys in dictianary

#x.get("name"):it will give the value of the specific keys

#we can fetch value of key using name of the specific key and can fetch the values of list using index values 

#task1 :: make profile dictionany with diff keys and there values, print all keys left side and values on right side using while loop
#other tasks are on google drive

