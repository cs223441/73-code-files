/*

constructor :   
------------
            .it's a special type of function which has same name as it's class name
            .it's initializes in class when a object created
            .constructor has same return type as it's class return type
            
            types:
            ------
                .parameterized(which constructor has paramerts)
                .copy(which constructor has not parameters)
                .default/non parameterized(having no parameters)
*/

//parameterized constructor:

/*
destructor:
------------
            .it's same like constructor 
            .it destroys the object created by the constructor
            .it's symbol is tilde (~)
            .it's also a special member function liek : test() ,executed automatically when a obect get's destroyed
            .it frees(de-allocate) up the memory space

*/

/*Eg :-

#include <iostream>
using namespace std;

class U{
    public:
    
    U(){
        cout<<"object declared!";
        cout<<"\n";
    }
      
    ~U(){
        cout<<"object destroyed!";
    }
    
};

int main()
{
   U op;
   
    return 0;
}
*/





