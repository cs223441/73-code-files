/*
   Write a C++ program to check a given integer and return true if it is within 10 or 100 or 200. Go to the editor
   Sample Input:
*/
#include <iostream>
using namespace std;
int main()
{
    int a;
    
    
    cout<<"enter value of a:";
    cin>>a;

       
        if(a>10 && a<100 && a<200){
        cout<<"true";
        }
       else {
           cout<<"false";
           
       }
    
}