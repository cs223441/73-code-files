#cyclic shift:
#given list:[A0,A1,A2,A3,A4,A(n-1)] to convert : in [A1,A2,A3,A(n-1),A0]
h=6
i=[0,1,2,3,4,5]
y=0
while y<=h:
    g=i.pop(0)
    i.append(g)
    y=y+1
print(i)
