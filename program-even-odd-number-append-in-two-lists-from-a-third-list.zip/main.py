'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
t=int(input("enter numbers to get even and odd in sorted order:>")
t=t.sort()
t=list(t)
even=[]
odd=[]

i=0
while i<=t(len):
    h=t.pop(t[i])
    if(h%2==0):
        h=h.append(even)
    elif(h%2!=0):
        h=h.append(odd)
        
else:
    t=t.remove()
    print(t)
    print(even)
    print(odd)

