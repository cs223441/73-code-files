/*

refernce variable : the variable is the alternating name of existing variable is called refernce variable 
-----------------   this variable stores the address of the existing variable
                    to create a reference variable we use '&' with the new variable and = existing variable 

conditions:the variable should be existing which reference variable we are declaring of and the reference variable must declare in 
           beginning,if type of reference variable must same as the existing variable

syntax: &newvariable = existing variable
*/

//eg:
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a = 20;
    int &b=a;
    int &cd=b;
    cout<<"reference variable b having value : "<<b<<"\n";
    cout<<"original variable a having value : "<<a<<"\n";
    cout<<"cd having value : "<<cd;
    
    return 0;
}
