/******************************************************************************
----------------
freind function: we declare a function as freind using freind keyword which allows to  access all the properties of private and
-------------     protected class even the function is not member of that class

NOTE:- we don't use the object of class as argument of friend function at time of calling instead of using dot(.) operator  

syntax : 
--------
step 1 : declaration using freind(class& obj)
step 2 : defininition using void(class& obj) 
step 3 : calling using function_name in main 
freind return_type function_name(class_name refrence variable) int{
}

types of freind function : global function , member function 

*******************************************************************************/
#include <iostream>
#include<conio.h>

using namespace std;

/*
//friend function as member function

class kl{
    private:
    int a = 10;
    
    protected:
    int b=20;
    
    friend void newfrfun(kl& ob);
};

    void newfrfun(kl& ob){
        cout<<"value 1 : "<<ob.a<<endl;
        cout<<"valeu 2 : "<<ob.b<<endl;
    }
    
int main(){
        kl obj;
        newfrfun(obj);
        return 0;
}
*/

 class k{
     private:
     int a ,b;
    
     };
     
    friend void rect_out(k& ob);


void rect_out(area_rect& ob){
    cout<<"enter a:";
    cin>>a;
    cout<<"enter b:";
    cin>>b;
    
    cout<<"output:"<<a*b;
}

int main(){
    k jl;
    jl.area_rect();
    rect_out(jl)
}





















