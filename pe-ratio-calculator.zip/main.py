'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#ROCE = earning before interest and tax / capital employed
name=str(input("enter name of company:"))

ebit=float(input("Enter EBIT Units:"))
ce=float(input("Enter Capital Employed:"))

ROCE=ebit/ce
print(name,"company ROCE is:",ROCE,"units")

