'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

searching:
----------
p=int(input("search number:"))

a=[1,2,3,4,5,6,7]

for i in range(len(a)):
    if(p==a[i]):
        print("your value is on",i,"index number and your value is:",a[i])


l=["chaitanya","surendra","akhilesh","mayank","devesh","sarvesh","deepak"]
a=input("Search anything :")

for i in range(len(l)):
    if(a==l[i]):
        print("found your value at index no:",i,"and value is",l[i])
    else:
        print("not found")
        
'''
x=["chaitanya sharma is a good boy with good coding skills and he's is very carefull about the mistakes he has made in his past life"]

f=input("search:")

for i in range(len(x)):
    if(f==x[i]):
        print("value is:",x[i])
        
        
        
        
        
        
        
        
        
        