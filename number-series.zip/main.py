'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
'''
o=0
while o<2:
    c=0
    while c<4:
        print(o,c)
        c=c+1
    o=o+1    
        
y=1
while y>-1:
    g=2
    while g>=0:
        print(y,g)
        g=g-1
    y=y-1
    
o=1
while o>=0:
    y=1
    while y<=4:
        print(o,y)
        y=y+1
    o=o-1
    
    
e=2
while e<=5:
    g=5
    while g>1:
        print(e,g)
        g=g-1
    e=e+1
    
    
i=10
while i>=9:
    f=20
    while f>=0:
        print(i,f)
        f=f-10
    i=i-1
    '''
