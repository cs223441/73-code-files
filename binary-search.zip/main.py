


l=[1,2,3,4,9,10,20,30,40,50,60,70,80,90,100,102,104,106,107,109]

i=int(input("Search:"))
start=0
end=len(l)


while start<=end:
    
    mid=(start+end)/2
    mid=int(mid)
    if(i==l[mid]):
        print(f"got {i} at position : {mid}")
        break
    elif(i<l[mid]):
        end=mid
   
    elif i>l[mid]:
        start=mid

    elif start>end:
        print("not found,sorry!")