'''
#searching through tuple

i=input("search anything:-")
t=("chaitanya","sharma","surendra","sarvesh","devesh","gaurav")


for u in range(0,len(t)):
    if i==t[u]:
        print(f"got {t[u]} at {u}")
        
'''        

y=input("search any:")
t=["Lorem ipsum dolor sit amet consectetur adipiscing elit"]

for u in range(0,len(t)):
    if t[u]==y:
        print(f"your searched result is : {t[u]} at- {u}")
    