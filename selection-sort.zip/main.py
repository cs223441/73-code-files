'''
selection sort theory:
----------------------
first we will apply 1st loop for iterating n-1 values in the list because n has to be compared with it's next one tha't and if we will not assign n-1,
it will go to last most value of list and will try to compare with it's next one but as you can see, there is no value remaining.

now second loop is for the nex value of sorting values like [5,24,3,4,1,5] here 5 is the value which has to compare with all element and n+1 is the all
next values comming in list to sort list 

then we will print list. tha's it!
'''

#selection sort:
---------------
u=[3,4,1,3,54,5,2,1,35,5]
for i in range(0,len(u)-1):
    for y in range(i+1,len(u)):
        if(u[i]>u[y]):
            g=u[i]
            u[i]=u[y]
            u[y]=g
            
print(u)
