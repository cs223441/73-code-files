#include <iostream>
using namespace std;

/*
access specifiers:
    public:the class objects can be accessed from inside and outside the class
    private:the class objects can only be accessed from inside the class
    protected:the class objects can be accessed from inside the class and inherited class
    
    note:- by default access specifier is private,to make is accsible from outside and inside we have to declare it as public or protected
*/

//code :- 
class student_details{
    public://access specifier
    
    int roll;//data members of student_details
    char fname[15];
    char lname[15];
    
    void input(){//member function of student_details
         cout<<"enter roll : ";
         cin>>roll;
         cout<<"enter fname :";
         cin>>fname;
         cout<<"enter lname :";
         cin>>lname;
         
    }
    
    void out2(){
       cout<<"details:"<<endl;
    }
    
};

class student_show : public student_details{
    public://access specifier
    
    //inheritance begins over here
        void st_get(){//inherited member function 
         input();   
        }

        void out(){//member function of student_show
        cout<<"roll : "<<roll<<endl;
        cout<<"fname :"<<fname<<endl;
        cout<<"lname : "<<lname<<endl;
        };
};

int main(){
    student_show s2;//student_show object
    s2.st_get();
    
    student_details s1;//student_details object
    s1.out2();
    s2.out();
};