/******************************************************************************
inline function: the function which is declared in single line is called inline function
                    to declare a function inline inline keyword is used before function definition and the function should in single line 

this is a request to compiler and not a command 

compiler can ignore the request

inline request makes the execution of code in single line 

it executes the function by copying the code body at calling time !

it fasts the code execution

we declare the function as inline when we need fast execution and short requirements of function execution

syntax:
    inline return type function_name(parameters){
    
    }

*******************************************************************************/
//eg:

#include <iostream>

using namespace std;

class operations
{
public:

  int a, b, mul, add, subt;
  float divi;

  void getval ();
  void adding ();
  void mult ();
  void subtr ();
  void divis ();
};

inline void operations::getval ()
{
  cout << "enter a : ";
  cin >> a;

  cout << "enter b : ";
  cin >> b;
}

inline void operations::adding ()
{
  cout << "addition : " << a + b;
}

inline void operations::mult ()
{
  cout << "\nmultiplication : " << a * b;
}

inline void operations::subtr ()
{
  cout << "\nsubtraction : " << a - b;

}

inline void operations::divis ()
{
  cout << "\ndivision : " << a / b;
}

int main ()
{
  operations j1;
  j1.getval ();
  j1.adding ();
  j1.mult ();
  j1.subtr ();
  j1.divis ();
  return 0;

}
