/******************************************************************************
 
    Write a C++ program to declare Struct. Initialize and display contents of member variables

*******************************************************************************/
//sol.

#include <iostream>
using namespace std;

struct A{
    int age;
    float height;
    char name[20];
    int weight;
    
    void get();
    void set();
};

void A::get(){
    cout<<"enter name : ";
    cin>>name;
    
    cout<<"enter age : ";
    cin>>age;
    
    cout<<"enter height : ";
    cin>>height;
    
    cout<<"enter weight : ";
    cin>>weight;
}

void A::set(){
    cout<<endl;
    cout<<"details"<<endl;
    cout<<"--------"<<endl;
    cout<<"name : "<<name;
    cout<<", age : "<<age;
    cout<<", height : "<<height;
    cout<<", weight : "<<weight;
}

int main()
{
    A co;
    co.get();
    co.set();
    return 0;
}