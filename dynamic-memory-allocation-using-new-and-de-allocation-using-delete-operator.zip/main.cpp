/******************************************************************************

memory allocation using new and de-allocating using delete operator

new operator : it is request to allocate new memory if sufficient space available and allocates(initializes) new memory in stack to programm 
               and returns the address of newly initlized memory to pointer variable 
    syntax : *pointername = new datatype ;
    .the datatype of pointer and after new must same 
    
delete operator : it de-allocates the allocates memory space from stack
    syntax : 
    
*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    //eg1:
   
   /*
   int *ghost;
   
   ghost=new int;//allocating new memory 
   
   *ghost=2324;
   
   cout<<*ghost<<endl;
   cout<<ghost<<endl;
   
   delete ghost;//de-allocating memory
   
   cout<<*ghost;
   cout<<ghost;
   */
    
   //eg 2: 
   int *jo;
   
   jo=new int ;
   
   *jo=3245;
   
   cout<<*jo<<endl;
   cout<<jo<<endl;
   
   delete jo;
   
   cout<<*jo<<endl;
   cout<<jo;
    
    return 0;
}