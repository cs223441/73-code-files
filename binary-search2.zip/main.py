'''binay search'''

o=[1,2,3,4,5,6,7]

for j in range(0,len(o)-1):
    for i in range(0,len(o)-1):
        if o[i]>o[i+1]:
        
            swap=o[i]
            o[i]=o[i+1]
            o[i+1]=swap
print(o)    

#searching element:
k=int(input("Search for any number: "))
start=0
end=len(o)
while start<=end:
    mid=(start+end)/2
    mid=int(mid)
    
    if(k==o[mid]):
        print(f"Got {k} at {mid} Position")
        break
    elif k<mid:
        end=mid
    elif k>mid:
        start=mid
        
        