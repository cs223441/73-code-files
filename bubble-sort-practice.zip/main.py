'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
i=[3,4,5,56,7,6,2,52,42,34]
even=[]
for u in range(1):
    if(i[u]%2==0):
        i.pop(i[u])
        even.append(i[u])
        
else:
    print(i)
    print(even)
    
            