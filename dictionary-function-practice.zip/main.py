#practice of printing dictionary keys and values with loop

t={"name":"chaitanya","sname":"sharma","freindname":"surendra","email":"chaitanya43455@gmail.com","roll":"34402"}

f=list(t.keys())
g=list(t.values())

i=0
while i<len(t):
    print(f[i],g[i])
    i=i+1
    
    
f=list(t.keys())
g=list(t.values())
i=0
while i< len(t):
    print(f[i])
    print(g[i])
    i=i+1
    
    
k={1,3,4,5,6,7}
l={2,3,5,6,78,6}

print(k.union(l))
print(k.intersection(l))
print(k.difference(l))
print(k.symmetric_difference(l))
