/******************************************************************************

pointer variable : this is the variable which stores the address of another variable
----------------   pointer can also store the value of another variable 

syntax:
------
to store the address or value in pointer of another variable:
    datatype *pointername = &variable;
    
   1. to show value of stored variable:
            cout<<*pointername;
            
   2. to show the address of stored variable:
            cout<<pointername;
    
   '&': it copies the address of variable
   '*': it access the value of address

*******************************************************************************/

//eg:

#include <iostream>

using namespace std;

int main()
{
    int h=20;
    int *ghost=&h;
    cout<<"value of pointer:"<<*ghost;
    cout<<"\naddress of pointer:"<<ghost;
}