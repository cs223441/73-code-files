/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

/* copy constructor:-
   ------------------
class mic{
    public:
    int x , y;
    
    mic(int a , int b){
        x=a;
        y=b;
    }
    
    mic(mic &ref){ // --> copy constructor working (declaring a,b value to x,y using reference variable)
        x=ref.x;
        y=ref.y;
    }
    
    void output();
};

void mic :: output(){
        cout<<x<<" "<<y<<endl;
    } 
int main(){
    mic top(30,20);
    mic top2=top; // --> copy constructor functioning (declaring value of a object to other object)
    top.output();
    top2.output();
}*/



/*
//paramiterized constructor: in which constructor paramerters are occured
----------------------------

class sick{
    public:
    int aa,bb;
    sick(int x , int y ){
        aa=x,bb=y;
    }
    void show(){
        cout<<aa<<" "<<bb<<endl;
    }
};
int main(){
    sick kl1(20,30);
    sick kl2(40,50);
    sick kl3(52,56);
    kl1.show();
    kl2.show();
    kl3.show();
}
*/

/*
//default constructor : which constructor have not any paramerters 
---------------------

class berald{
    public:
    berald(){
        cout<<"hi chaianya sharma!,";
        cout<<"object constructor is initialized"<<endl;
    }
    
    ~berald(){
        cout<<"object destroyed!";
    }
};
int main(){
    berald b1;

}
*/