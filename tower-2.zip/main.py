'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''

for row in range(8):
    for space in range(row,-1,-1):
        print(" ")
        for star in range(1,row-1,1):
            print("*",end="")
else:
    print(" ")
    