'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
l={1,2,3,4,5,6,7,8,9}
k={1,2,4,5,6}
print(k.issubset(l))

v={3,5,6,7,24,3}
c={32,3,6,7,3,2}
print(v.issubset(c))

b={2,3,4,2,4,5,6}
h={2,3,4,5,6,7,8,23}
print(b.issubset(h))

b1={23,4,5,24,56,6}

b2={23,234,245,5,52,24,6,4,56}

print(b2.issubset(b1))

l={1,2,3,4,5}
b={1,2,3,4,5}
print(l.issubset(b))


l={1,23,4,52,2,4,5}
h={3,1,4,5,2,35,5}
print(l-h)
print(l.difference(h))


