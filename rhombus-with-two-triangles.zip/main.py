


i=int(input("enter rows for upfaced:>>")) #input for upper triangle 
j=int(input("enter rows downfaced:>>"))  #input for lower triangle
print()#next line 
print()#next line

#code for upper triangle:

for rows in range(i):
    for sp in range(i-rows+5):
        print(end=" ")
    for st in range(0,rows+1):
        print("&",end=" ")
    print()
    
#code for lower triangle:    
    
for row in range(j):
    r=1
    for sps in range(row*r+6):
        print(end=" ")
        
    for ste in range(j-row):
        print("&",end=" ")
    print()
    
    
    
    
    
    
    
    
    
 
