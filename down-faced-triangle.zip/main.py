'''

i=int(input("enter the rows:"))
print()
print()
for rows in range(i):
    for space in range(0,i-rows+5):
        print(end=" ")
    for st in range(0,rows+1):
        print("*",end=" ")
    print()
    
'''

'''

i=int(input("enter rows:"))
print()
print()
for rows in range(i):
    so=1
    for sp in range(rows*so+5):
        print(end=" ")
    for st in range(i-rows):
        print("*",end=" ")
    print()
'''


i=int(input("enter rows for uppper:"))

y=int(input("enter rows for lower:"))

print()
print()


#upper triangle code:

for rows in range(i):
    for sp in range(i-rows+5):
        print(end=" ")
    for st in range(0,rows+1):
        print("*",end=" ")
    print()


#lower triangle code:

for row in range(y):
    g=1
    for u in range(row*g+6):
        print(end=" ")
        
    for f in range(0,y-row):
        print("*",end=" ")
    print()
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
