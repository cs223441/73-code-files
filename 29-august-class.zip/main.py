'''p=["chaitanya",["surendra","sarvesh","hitesh","mitesh","lokesh",[13,3,5,6,73,2,4,5,6]]]
p[1][5].sort()
print(p)


#l=[2,3,4,5,6,7,8,8]


x.intersection_update(y)
x.update(y)
x.symmertric_difference_update(y)
x.add("value")
x.remove("value")
x.discard("value)
y.issubset(x)
y.issuperset(y)
father=[]
mother=[]
siblin=[]
you=[]

#frozen set
x.frozenset({1,2,3,4,5})


c=[1,23,3,5,6,7,8,9]

f=[]

u=0
while u<=c(len):
        f=c.pop() 
        



#x.split(" ")
'''


'''
r={3,4,6,7,8}
k={3.2,7,8,2,4,6}

r.intersection(k)
print(r)

r.update(k)
print(r)

r.difference(k)
print(r)

r.intersection(k)

print(r)

k.union(r)
print(k)
'''
'''
l={2,3,5,3,2}
s={1,3,4,4,2,5}

l.difference(s)
print(l)

l.symmetric_difference(s)
print(l)

'''
l=[1,2,3,4,45,6,7,8,9,10]
even=[]
odd=[]
#starting::

k=0
while k<len(l):
        l=l.pop(k)
        if(l%2==0):
            l.append(even)
        else:
            l.append(odd)
        k=k+1
else:        
    print(even)
    print(odd)
    


















