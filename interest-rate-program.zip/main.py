


#Q: 50000 for 1 year 5 % interest rate find how much interest has to pay after one year:

#(amount*interest)/100

q=1
while q<2:
    amount=float(input("Enter Amount Borrowed from Bank:"))
    
    interest_rate=float(input("Enter interest Rate: "))
    
    interest=(amount*interest_rate)/100
    
    print(interest,"is the interest you have to pay")
    
    q=q+1    



p=1
while p<2:
    amount=float(input("Enter Amount Borrowed from Bank:"))
    
    interest_rate=float(input("Enter interest Rate: "))
    
    interest=(amount*interest_rate)/100
    
    print(interest,"is the interest you have to pay")
    
    p=p+1    

