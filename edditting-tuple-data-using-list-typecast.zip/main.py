
'''
Q(1)>> x=("chaitanya","devesh","sarvesh",[1,2,4,5,6,7,8,("c++","c#","J#","java","js",("thirty",3.45,3.2,"hello"))]) 

- (replace devesh with neeraj) , (replace c# with django) , (replace thirty with twenty)

'''
x=("chaitanya","devesh","sarvesh",[1,2,4,5,6,7,8,("c++","c#","J#","java","js",("thirty",3.45,3.2,"hello"))]) 


#converting most outer tuple into list:
x=list(x)
print(x)


#converting first internal tuple into list::
x[3][7]=list(x[3][7])
print(x)


#converting second internal tuple into list:::
x[3][7][5]=list(x[3][7][5])
print(x)

x[1]="Neeraj singh"
x[3][7][0]="django"
x[3][7][5][0]="twenty"
print(x)


#convertin all tuples into list again:::

#second internal list::
x[3][7][5]=tuple(x[3][7][5])

#first internal list::
x[3][7]=tuple(x[3][7])

#external list::
x=tuple(x)

print(x)

