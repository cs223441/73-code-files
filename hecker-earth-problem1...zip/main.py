'''
Q:
Here T is 1, which means one test case.
denoting the number of elements in the array and , denoting the number of steps of rotations.
The initial array is:12345 
In first rotation, 5 will come in the first position and all other elements will move to one position ahead from their current position. Now, the resultant array will be 51234
In second rotation, 4 will come in the first position and all other elements will move to one position ahead from their current position. Now, the resultant array will be 54123

'''

#sol->
t=[1,2,3,4,5]
i=1
while i<=2:
    h=t.pop()
    t.insert(0,h)
    i=i+1
    if(i>2):
        break
print(t)


