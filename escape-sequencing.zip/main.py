#Excape sequencing : to change the default sequence of output by implementing some keywords and syntax

##double quotes and single quotes rules::

print('''hello it's "me" "chaitanya"''')
print("""hello "vefa"it's me "chaitanya" """)

print("hello it's me ")

print("how are' you mr' man")

print("""hello "world" GO""")

print("""hello"how" "are" "you" man""")

print('my name is "chaitanya"')

print("""hello my name is "chaitanya"
and 
i'am 
learning 
python and salesforce,thank you.""")

print("""hello,i love coding. but sometimes 
maths makes it 
difficult for 
me. can you help me??""",end="\n\n")


# escaping sequencing:: 
print("hello", end="\n\n")  
print("how are you:>?")    

print("hello", end="\n\t")  
print("how are you:>?")    

print("hello", end="\n\t\t")  
print("how are you:>?")    

print("hello", end="\n\n\n\t\t\t")  
print("how are you:>?")    

print("chaitanya sharma")
print("chaitanya \n\t\tsharma")

print("hello this is \\\\chaitanya\\\\sharma")

print("hello this is \\\\\\chaitanya\\\\\\sharma")

print("hello this is chaitanya sharma and iam interested in \\coding\\and \\\\love\\\\ to \\\\play\\\\\\ with it")
print()
print()
print()

print("my name is chaitanya ")
print()
print()
print()
print()
print("sharma")

print("hello", end="")


