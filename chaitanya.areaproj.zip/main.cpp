/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

int main ()
{
  int vol_of_clindr; 
int h;
int r;

cout<<"Enter h and r:";

cin>>h>>r;

3.14*r*r*h;

cout<<"vol_of_clindr:"<<vol_of_clindr<<"m^3";
  return 0;
}
