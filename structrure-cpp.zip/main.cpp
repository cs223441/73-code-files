/******************************************************************************
structure:it's user defined data type 
.same as class but it's used to store multiple datatype variables
.example is follows

*******************************************************************************/
#include <iostream>

using namespace std;

struct student{
    int roll;
    char fname[20];
    char lname[15];
    char section[1];
    float obtained_marks;

    void input(){
      cout<<"enter roll:"<<endl;
      cin>>roll;
      
      cout<<"enter fname:"<<endl;
      cin>>fname;
      
      cout<<"enter lname:"<<endl;
      cin>>lname;
      
      cout<<"enter section:"<<endl;
      cin>>section;
      
      cout<<"enter obtained_marks:"<<endl;
      cin>>obtained_marks;
      
    };
    void output(){
      cout<<"roll:"<<roll<<endl;
      cout<<"fname:"<<fname<<endl;
      cout<<"lname:"<<lname<<endl;
      cout<<"section:"<<section<<endl;
      cout<<"obtained obtained_marks:"<<obtained_marks<<endl;
      
    };
};

int main()
{
    student newobj;
    for(int i=0;i<3;i++){
        newobj.input();
        newobj.output();
    }


    return 0;
}