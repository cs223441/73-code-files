/******************************************************************************
----------------
freind function: we declare a function as freind using freind keyword which allows to  access all the properties of private and
-------------     protected class even the function is not member of that class

NOTE:- we don't use the object of class as argument of friend function at time of calling instead of using dot(.) operator  

syntax : 
--------
step 1 : declaration using freind(class& obj)
step 2 : defininition using void(class& obj) 
step 3 : calling using function_name in main 
freind return_type function_name(class_name refrence variable) int{
}

types of freind function : global function , member function 

*******************************************************************************/
#include <iostream>
#include<conio.h>

using namespace std;

/*
//friend function as member function

class kl{
    private:
    int a = 10;
    
    protected:
    int b=20;
    
    friend void newfrfun(kl& ob);
};

    void newfrfun(kl& ob){
        cout<<"value 1 : "<<ob.a<<endl;
        cout<<"valeu 2 : "<<ob.b<<endl;
    }
    
int main(){
        kl obj;
        newfrfun(obj);
        return 0;
}
*/

//eg 2:

/*
class gh{
    private:
    int a,b;
    
    void friend getval(gh& io);
    
    public:
    void setval(){
        cout<<"value:"<<a*b;
    }
};


void getval(gh& io){
    cout<<"enter a:";
    cin>>io.a;
    
    cout<<"enter b:";
    cin>>io.b;
}
    
int main(){
    gh lm;
    getval(lm);
    lm.setval();
}
*/

//-------------------------------------------------------------------------------------------------------

/*
friend class: it is the class which can access the private and protected members of another class in which it's defined as friend 
------------

friend keyword is used to declare the class as friend class 
friend class is declared in another class 

syntax:
    class name{
        friend class_name; declarating class as friend
    }
    class class_name{ :- class declaration
        
    }
*/

//eg:

class yur{
    
    private:
    int a;
    
    protected:
    float b;
    
    public:
    void jk(){
        int a=20;
        float b=10;
    }
    friend class tu;
};

class yu{
    
    public:
    void disp(yur& mm){
        cout<<"value 1:"<<mm.a;
        cout<<"value 2:"<<mm.b;
    }
};

int main(){
    yur tt;
    yu jm;
    
    jm.disp(tt);

    return 0;
}















